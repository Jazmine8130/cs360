package com.zybooks.arielfooroption1project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserDAO {
    private SQLiteDatabase database;
    private DatabaseUsers dbUsers;

    //creates user database
    public UserDAO(Context context) {
        dbUsers = new DatabaseUsers(context);
    }

    public void open() throws SQLException {
        database = dbUsers.getWritableDatabase();
    }

    public void close() {
        dbUsers.close();
    }

    //adds users to the database
    public void addUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(DatabaseUsers.COLUMN_USERNAME, username);
        values.put(DatabaseUsers.COLUMN_PASSWORD, password);
        database.insert(DatabaseUsers.TABLE_USERS, null, values);
    }

    // checks if username and password are both filled in
    public boolean checkUser(String username, String password) {
        String[] columns = { DatabaseUsers.COLUMN_ID };
        String selection = DatabaseUsers.COLUMN_USERNAME + " = ? AND " + DatabaseUsers.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };
        Cursor cursor = database.query(DatabaseUsers.TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    //checks if username is already in use
    public boolean userExists(String username) {
        String[] columns = { DatabaseUsers.COLUMN_ID };
        String selection = DatabaseUsers.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = { username };
        Cursor cursor = database.query(DatabaseUsers.TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }
}