package com.zybooks.arielfooroption1project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//main activity, starts at the log in screen
public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private UserDAO userDAO;

    //starts on log in screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.login_username);
        passwordEditText = findViewById(R.id.login_password);
        Button loginButton = findViewById(R.id.log_in);
        Button signUpButton = findViewById(R.id.sign_up);

        userDAO = new UserDAO(this);
        userDAO.open();

        //waits for user to click before verifying username and password
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();
            if (userDAO.checkUser(username, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, ActivityInventoryScreen.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // wait for user click to add user or error if already in database
        signUpButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();
            if (userDAO.userExists(username)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else {
                userDAO.addUser(username, password);
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SmsNotificationsActivity.class);
                startActivity(intent);
            }
        });
    }

    //closes app
    @Override
    protected void onDestroy() {
        userDAO.close();
        super.onDestroy();
    }
}
