package com.zybooks.arielfooroption1project2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public class ActivityInventoryScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_screen);

        ItemDAO itemDAO = new ItemDAOImpl(this);
        RecyclerView recyclerView = findViewById(R.id.item_recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns

        List<Item> itemList = itemDAO.getAllItems();
        MyAdapter adapter = new MyAdapter(this, itemList);
        recyclerView.setAdapter(adapter);


    }
}
