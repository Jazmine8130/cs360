package com.zybooks.arielfooroption1project2;

import java.util.List;

public interface ItemDAO {
    void addItem(Item item);

    List<Item> getAllItems();

    void updateItem(Item item);

    void deleteItem(int id);

}
