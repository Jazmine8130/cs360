package com.zybooks.arielfooroption1project2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationsActivity extends AppCompatActivity {

        // loads sms notification screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        Button sendButton = findViewById(R.id.send_button);
        sendButton.setOnClickListener(this::onButtonClick);

        View toggleSwitch = findViewById(R.id.switch1);
        View sms_prompt = findViewById(R.id.sms_prompt);

        // hides phone number box and send sms button until it is selected.
        ((Switch) toggleSwitch).setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                sms_prompt.setVisibility(View.VISIBLE);
            } else {
                sms_prompt.setVisibility(View.GONE);
            }
        });

    }
    //sends permission once the button is clicked
    public void onButtonClick(View v) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
        } else {
            sendSMS();
        }
    }

    public void onButtonClickClose(View v) {

    }
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;

    //sends message to number if they have clicked to enable notifications
    private void sendSMS() {
        EditText phoneText = findViewById(R.id.editTextPhone);
        String phoneNumber = phoneText.getText().toString();
        String message = "This is an example of a notification sent to " + phoneNumber;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS Sent to: " + phoneNumber, Toast.LENGTH_SHORT).show();

                Button sendButton = findViewById(R.id.send_button);
                sendButton.setOnClickListener(v -> sendSMS());
            } catch (Exception e) {
                Toast.makeText(this, "SMS Failed to Send", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            Button closeButton = findViewById(R.id.close_button);
            closeButton.setOnClickListener(v -> finish());
            Intent intent = new Intent(SmsNotificationsActivity.this, ActivityInventoryScreen.class);
            startActivity(intent);
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
