package com.zybooks.arielfooroption1project2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemDAOImpl implements ItemDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public ItemDAOImpl(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    @Override
    public void addItem(Item item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", item.getName());
        values.put("quantity", item.getQuantity());
        values.put("imageResId", item.getImageResId());
        db.insert("inventory", null, values);
        db.close();
    }

    @Override
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_QUANTITY));
                @SuppressLint("Range") int imageResId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE_RES_ID));
                itemList.add(new Item(id, name, quantity, imageResId));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }

    @Override
    public void updateItem(Item item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", item.getName());
        values.put("quantity", item.getQuantity());
        values.put("imageResId", item.getImageResId());
        db.update("inventory", values, "id = ?", new String[]{String.valueOf(item.getId())});
        db.close();
    }

    @Override
    public void deleteItem(int id) {
        db = dbHelper.getWritableDatabase();
        db.delete("inventory", "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}

