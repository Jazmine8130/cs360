package com.zybooks.arielfooroption1project2;

public class Item {
    private int id;
    private String name;
    private int quantity;
    private int imageResId;

    public Item(int id, String name, int quantity, int imageResId) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.imageResId = imageResId;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getImageResId() {
        return imageResId;
    }
}
